<html lang="es">
    <head>
        <title>Oiga Martin</title>
        <meta charset="UTF-8"> 
        <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1, maximum-scale=1,  minimum-scale=1">
        <link rel="stylesheet" type="text/css" href="css/fontello.css">
        <link rel="stylesheet" type="text/css" HREF="css/estilos.css">
        <link rel="stylesheet" type="text/css" href="css/banner.css">
        <link rel="stylesheet" type="text/css" href="css/blog.css">
        <link rel="icon" href="img/ico.ico" type="image/x-icon" />
    </head>
    
    <body>
        <header>
            <div class="contenedor">
                <h1 class="icon-bullhorn">Oiga Martín!</h1>
                <input type="checkbox" id="menu-bar">
                <label class="icon-menu" for="menu-bar"></label>
                <nav class="menu">
                    <a href="index.php">Inicio</a>
                    <a href="https://www.facebook.com/Oiga-Mart%C3%ADn-151641511912643/">Contacto</a>
                </nav>
            </div>
        </header>
        
        <main>
            <section id="blog">
                <br>
                <br>
                <br>
                <br>
                <br>
                <br>
                <form method="post" action="ingresar_accion.php" class="form-acceder">
                    <h2 align="center">Ingresa tus Datos</h2>
                    <br>
                    <br>
                    <br>
                    <div class="contenedor-inputs" class="form-acceder" align="center">
                        <input type="text" name="nom" placeholder="Usuario" required>
                        <input type="password" name="pass" placeholder="Contraseña" required >
                        
                        <input type="submit" value="Acceder" name="Acceder" align="center">
                        </div>
                </form>
            </section>
        </main>
        <footer>
            <br>
            <br>
            
            <div class="contenedor">
                <p class="copy">Oiga Martín! &copy; 2017</p> 
                <div class="sociales">
                   <a class="icon-facebook-official" href="https://www.facebook.com/Oiga-Mart%C3%ADn-151641511912643/"></a>
               </div>
           </div>
        </footer>
    </body>
</html>
