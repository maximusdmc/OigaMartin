<html lang="es">
    
<head>
    <title>Oiga Martin</title>
    <meta charset="UTF-8"> 
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1, maximum-scale=1,  minimum-scale=1">
    <link rel="stylesheet" type="text/css" href="css/fontello.css">
    <link rel="stylesheet" type="text/css" HREF="css/estilos.css">
    <link rel="stylesheet" type="text/css" href="css/banner.css">
    <link rel="stylesheet" type="text/css" href="css/blog.css">
    <link rel="icon" href="img/ico.ico" type="image/x-icon" />
</head>
    
    <body>
        <header>
            <div class="contenedor">
                <h1 class="icon-bullhorn">Oiga Martín!</h1>
                <input type="checkbox" id="menu-bar">
                <label class="icon-menu" for="menu-bar"></label>
                <nav class="menu">
                    <a href="iniciar.php">Iniciar Sesion</a>
                   
                    <a href="https://www.facebook.com/Oiga-Mart%C3%ADn-151641511912643/">Contacto</a>
                </nav>
            </div>
        </header>
        
        <main>
           <section id="banner">
               <div id="slider">
                   <figure>
                       <img src="img/banner.jpg" alt>
                       <img src="img/baner2.jpg" alt>
                       <img src="img/baner3.jpg" alt>
                       <img src="img/baner2.jpg" alt>
                       <img src="img/banner.jpg" alt>
                   </figure>
               </div>
               <div class="contenedor">
               <h2>Oiga Martín</h2>
                   <p>Obten la app movil disponible para dispocitivos Android</p>
                   <a href="https://play.google.com/store/apps/details?id=somoslobos.mx.oigamartin&rdid=somoslobos.mx.oigamartin">Ir a PlayStore</a>
               </div>
            </section>
            <br>
                     <br>
                     <br>
                     <br>
                     <br>
                     <br>
            <section id="bienvenidos">
                
            
                     <br>
                     <br>
                <br>
                     <br>
                     <br>
                      <br>
                     <br>
                     <br>
                     <br>
                   <h2>Bienvenidos a Nuestra Pagina Oficial</h2>
                     
            </section>
            
            <section id="blog">
            
                         <div class="contenedor" >
                  
                         
                        <article>
                           <a><img src="img/pp.jpg"></a>
                        </article>
                         
                         <article>
                           <a><img src="img/pp2.jpg"></a>
                            </article>
                         <center>
                           <h4>Oiga martin, Reportes ciudadanos en la ciudad de Hidalgo del Parral</h4>
                        </center>
                   
            
                </div>
            
            
            </section>
                     <br>
                     <br>
                     <br>
                     <br>
                     <br>
                     <br>
                      <br>
            
            <section id="info">
                
                <div class="contenedor">
                      <div class="info-pag">
                         <img src="img/pag1.jpg" alt="">
                          <h4>Sensilla</h4>
                      </div>
                      <div class="info-pag">
                         <img src="img/pag2.jpg" alt="">
                          <h4>Facil de usar</h4>
                      </div>
                      <div class="info-pag">
                         <img src="img/pag3.jpg" alt="">
                          <h4>Util</h4>
                      </div>
                      <div class="info-pag">
                         <img src="img/pag4.jpg" alt="">
                          <h4>Muy cool</h4>
                      </div>
                </div>
            </section>
        </main>
        
        <footer>
           <div class="contenedor">
                <p class="copy">Oiga Martín! &copy; 2017</p> 
                <div class="sociales">
                   <a class="icon-facebook-official" href="https://www.facebook.com/Oiga-Mart%C3%ADn-151641511912643/"></a>
               </div>
           </div>
        </footer>
    </body>
</html>
