<?php
    $db_user = "dbo625060452";
	$db_pass = "utp2016";
	$db_host = "db625060452.db.1and1.com";
    $db_name = "db625060452";
    $mysqli = new mysqli($db_host, $db_user, $db_pass, $db_name);
    /* check connection */
    if (mysqli_connect_errno()) {
        printf("Connect failed: %s\n", mysqli_connect_error());
        exit();
    }		

    $mysqli->query("SET NAMES 'utf8'");
    $sql="SELECT ruta FROM rutas";
    $result=$mysqli->query($sql);
    while($e=mysqli_fetch_assoc($result)){
        $output[]=$e; 
    }	

    print(json_encode($output)); 
    $mysqli->close();
?>		
