
<html lang="es">
    
<head>
    <title>Oiga Martín!</title>
    <meta charset="UTF-8"> 
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1, maximum-scale=1,  minimum-scale=1">
    <link rel="stylesheet" type="text/css" href="css/fontello.css">
    <link rel="stylesheet" type="text/css" HREF="css/estilos.css">
    <link rel="stylesheet" type="text/css" href="css/banner.css">
    <link rel="stylesheet" type="text/css" href="css/blog.css">
    <link rel="stylesheet" type="text/css" href="css/tabla.css">
    <link rel="icon" href="img/ico.ico" type="image/x-icon" />
</head>
    
    <body>
        <header>
            <div class="contenedor">
                <h1 class="icon-bullhorn">Bienvenido</h1>
                <input type="checkbox" id="menu-bar">
                <label class="icon-menu" for="menu-bar"></label>
                <nav class="menu">
                    <a href="cerrar_accion.php">Cerrar Sesion</a>
                   
                    <a href="https://www.facebook.com/Oiga-Mart%C3%ADn-151641511912643/">Contacto</a>
                </nav>
            </div>
        </header>
        
        <main>
           <br>
                     <br>
                     <br>
                     <br>
                      <br>
                
                    
                
                
                
                  
               
                    
                 
                     <br>
                     <br>
                      <br>
                        <h2 align="center">Listado de quejas</h2>
                     
                     <br>
                     <br>
                      <br>
                     
                    <div >
              
             
                       <table class="table-fill">
                            <thead>
                                <tr>
                                    <th class="text-left">NOMBRE</th>
                                    <th class="text-left">APELLIDOS</th>
                                    <th class="text-left">TELEFONO</th>
                                    <th class="text-left">CORREO</th>
                                    <th class="text-left">LATITUD</th>
                                    <th class="text-left">LONGITUD</th>
                                    <th class="text-left">COMENTARIO</th>
                                    
                                    <th class="text-left">REVISADO</th>
                                    <th class="text-left">IMAGEN</th>
                                    <th class="text-left">RESPONDER</th>
                                    <th class="text-left">ELIMINAR</th>
                                </tr>
                                
                                
                                 <?php
                      include("conexion.php");
                      
                      $query="SELECT * FROM reportes WHERE dependencia='cfe'";
                      $resultado=$conexion->query($query);
                      while($row=$resultado->fetch_assoc()){
                      ?>
                                
                            </thead>
                           
                            <tbody class="table-hover">
                                <tr>
                                   <td class="text-left" ><?php echo $row['nombre']; ?></td>
                                    <td class="text-left" ><?php echo $row['apellidos']; ?></td>
                                   <td class="text-left" ><?php echo $row['telefono']; ?></td>
                                   <td class="text-left"><?php echo $row['correo']; ?></td>
                                   <td class="text-left"><?php echo $row['latitud']; ?></td>
                                   <td class="text-left" ><?php echo $row['longitud']; ?></td>
                                    <td class="text-left" ><?php echo $row['comentario']; ?></td>
                                    <th class="text-left"><?php echo $row['solucionado']; ?></th>
                                    <td class="text-left"><img src="<?php echo $row['url_foto']; ?>" width="100%" height="100"></td>
                                        <td><a href="queja.php?id=<?php echo $row['id']; ?>">( ͡° ͜ʖ ͡°) </a></td>
                                    <td class="text-left"><a href="eliminar_accion.php?id=<?php echo $row['id']; ?>" >OK</a></td>
                                </tr>
                                
                                <?php
                          
                      }
                           
                          ?>
                                 
                            </tbody>
                        </table>
                        
                        
                    </div>
           
                     <br>
                     <br>
                     <br>
                     <br>
                      <br>
                     <br>
                     <br>
                     <br>
                     <br>
                      <br>
                     <br>
                     <br>
                     <br>
                     <br>
                      <br>
                     <br>
                     <br>
                     <br>
                     <br>
                      <br>
            <section id="info">
                
                <div class="contenedor">
                      <div class="info-pag">
                         <img src="img/pag1.jpg" alt="">
                          <h4>Sensilla</h4>
                      </div>
                      <div class="info-pag">
                         <img src="img/pag2.jpg" alt="">
                          <h4>Facil de usar</h4>
                      </div>
                      <div class="info-pag">
                         <img src="img/pag3.jpg" alt="">
                          <h4>Util</h4>
                      </div>
                      <div class="info-pag">
                         <img src="img/pag4.jpg" alt="">
                          <h4>Muy cool</h4>
                      </div>
                </div>
            </section>
        </main>
        
        <footer>
           <div class="contenedor">
                <p class="copy">Oiga Martín! &copy; 2017</p> 
                <div class="sociales">
                   <a class="icon-facebook-official" href="https://www.facebook.com/Oiga-Mart%C3%ADn-151641511912643/"></a>
               </div>
           </div>
        </footer>
    </body>
</html>
