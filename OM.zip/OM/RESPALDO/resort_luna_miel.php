 <?php
    
    if(!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
    } else {
        $ip = $_SERVER['REMOTE_ADDR'];
    }
    $navegador = $_SERVER['HTTP_USER_AGENT']."\r\n";
    $archivo = "log.txt";
    $manejador = fopen($archivo,"a") or die("Imposible abrir el archivo\n");

    fwrite($manejador,"DIRECCION: ".$ip." NAVEGADOR: ".$navegador);
    fclose($manejador);

?> 
