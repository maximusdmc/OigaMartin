<?php
   



$usuario=$_POST['nom'];
   $clave=$_POST['pass'];


   if(($usuario=="jmas")&&($clave="pass")){
       header('Location: jmas.php');
   }

   else if(($usuario=="cfe")&&($clave="pass")){
      header('Location: cfe.php');
   }

   else if(($usuario=="master"&&$clave="pass")){
      header('Location: master.php');
   }
   
   else if(($usuario=="obraspublicas"&&$clave="pass")){
      header('Location: obraspublicas.php');
   }
   
   else if(($usuario=="serviciospublicos"&&$clave="pass")){
      header('Location: serviciospublicos.php');
   }

else{
    echo('error');
}
?>