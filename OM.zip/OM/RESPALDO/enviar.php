<?php 

require_once('../class.phpmailer.php');
$mail = new PHPMailer();
//indico a la clase que use SMTP
$mail­>IsSMTP();
//permite modo debug para ver mensajes de las cosas que van ocurriendo
$mail­>SMTPDebug = 2;
//Debo de hacer autenticación SMTP
$mail­>SMTPAuth = true;
$mail­>SMTPSecure = "ssl";
//indico el servidor de Gmail para SMTP
$mail­>Host = "smtp.gmail.com";
//indico el puerto que usa Gmail
$mail­>Port = 465;
//indico un usuario / clave de un usuario de gmail
$mail­>Username = "andresknehci@gmail.com";
$mail­>Password = "426735int";
$mail­>SetFrom('andresknehci@gmail.com', 'Luis');
$mail­>AddReplyTo("andresknehci@gmail.com","Luis");
$mail­>Subject = "Envío de email usando SMTP de Gmail";
$mail­>MsgHTML("Tu queja se esta procesando");
//indico destinatario
$address = "montoyaluis166@gmail.com";
$mail­>AddAddress($address, "Luis Fernando Montoya");
if(!$mail­>Send()) {
echo "Error al enviar: " . $mail­>ErrorInfo;
} else {
echo "Mensaje enviado!";
}
?>