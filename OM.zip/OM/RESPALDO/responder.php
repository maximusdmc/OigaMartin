

<html lang="es">
    
<head>
    <title>Oiga Martín!</title>
    <meta charset="UTF-8"> 
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1, maximum-scale=1,  minimum-scale=1">
    <link rel="stylesheet" type="text/css" href="css/fontello.css">
    <link rel="stylesheet" type="text/css" HREF="css/estilos.css">
     <link rel="stylesheet" type="text/css" href="css/responder.css">
    <link rel="icon" href="img/ico.ico" type="image/x-icon" />
</head>
    
    <body>
        <header>
            <div class="contenedor">
                <h1 class="icon-bullhorn">Bienvenido</h1>
                <input type="checkbox" id="menu-bar">
                <label class="icon-menu" for="menu-bar"></label>
                <nav class="menu">
                    <a href="cerrar_accion.php">Cerrar Sesion</a>
                   
                    <a href="https://www.facebook.com/Oiga-Mart%C3%ADn-151641511912643/">Contacto</a>
                </nav>
            </div>
        </header>
        
        
        <br>
        <br>
        
        <br><br>
        <br>
        <br>
        <br>
        
        
        <form action="enviar.php">
            
            
            
             <?php
                      $id=$_REQUEST['id'];    
            
                      include("conexion.php");
                      
                      $query="SELECT * FROM reportes WHERE id='$id'";
                      $resultado=$conexion->query($query);
                      $row=$resultado->fetch_assoc();
                          
                       
                          
                      ?>
            
              <h2>Responder queja</h2>
            
                    <center> 
                          <img src="<?php echo $row['url_foto']; ?>" width="50%" height="50%" >
                    </center> 
            <br>
            <br>
                
                <input type="text" name="id" placeholder="Nombre" value="<?php echo $row['id'] ?>"required>
                <input type="text" name="nombre" placeholder="Nombre" value="<?php echo $row['nombre'] ?>"required>
                <input type="text" name="apellidos" placeholder="Nombre" value="<?php echo $row['apellidos'] ?>"required>
                <input type="text" name="telefono" placeholder="Telefono" value="<?php echo $row['telefono'] ?>"required>
                <input type="text" name="correo" placeholder="Correo" value="<?php echo $row['correo'] ?>"required>
                <input type="text" name="latitud" placeholder="Nombre" value="<?php echo $row['latitud'] ?>"required>
                <input type="text" name="longitud" placeholder="Nombre" value="<?php echo $row['longitud'] ?>"required>
                <input type="text" name="sulucionado" placeholder="Nombre" value="<?php echo $row['solucionado'] ?>"required>
                <input type="text" name="fecha" placeholder="Nombre" value="<?php echo $row['fecha'] ?>"required>
                <textarea name="mensaje" placeholder="Escriba la respuesta a la queja, se enviara un correo de notificacion" required></textarea>
                <input type="button" value="Enviar Correo" id="boton">
        
        </form>
        
          <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        
        <br><br>
        <br>
        <br>
        <br>
          <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        
        <br><br>
        <br>
        <br>
        <br>
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
    </body>
            <section id="info">
                
                <div class="contenedor">
                      <div class="info-pag">
                         <img src="img/pag1.jpg" alt="">
                          <h4>Sensilla</h4>
                      </div>
                      <div class="info-pag">
                         <img src="img/pag2.jpg" alt="">
                          <h4>Facil de usar</h4>
                      </div>
                      <div class="info-pag">
                         <img src="img/pag3.jpg" alt="">
                          <h4>Util</h4>
                      </div>
                      <div class="info-pag">
                         <img src="img/pag4.jpg" alt="">
                          <h4>Muy cool</h4>
                      </div>
                </div>
            </section>
        
        
        <footer>
           <div class="contenedor">
                <p class="copy">Oiga Martín! &copy; 2017</p> 
                <div class="sociales">
                   <a class="icon-facebook-official" href="https://www.facebook.com/Oiga-Mart%C3%ADn-151641511912643/"></a>
               </div>
           </div>
        </footer>
    </body>
</html>
