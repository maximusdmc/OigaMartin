 <?php
    session_start();  

   $conexion = mysqli_connect("db625060452.db.1and1.com","dbo625060452","ProyectoUTP2017") or die ('no se puede conectar la base de datos');
   mysqli_select_db($conexion,"db625060452") or die ('no se puede seleccionar la base de datos');
   
    $id=$_REQUEST['id']; 
    
    mysqli_query($conexion, "DELETE from reportes WHERE id='$id' ")
       or die ("Error al eliminar los datos");
    
    mysqli_close($conexion);
        echo "<script>alert('Reporte eliminado');</script>";
        echo "<script>window.history.back()</script>";
?>
