<html lang="es">
    
<head>
    <title>Where is the Bus?</title>
    <meta charset="UTF-8"> 
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1, maximum-scale=1,  minimum-scale=1">
    <link rel="stylesheet" type="text/css" href="css/fontello.css">
    <link rel="stylesheet" type="text/css" HREF="css/estilos.css">
    <link rel="stylesheet" type="text/css" href="css/banner.css">
    <link rel="stylesheet" type="text/css" href="css/blog.css">
</head>
    
    <body>
        <header>
            <div class="contenedor">
                <h1 class="icon-bus">Where is the Bus?</h1>
                <input type="checkbox" id="menu-bar">
                <label class="icon-menu" for="menu-bar"></label>
                <nav class="menu">
                    
                    <a href="index.php">Inicio</a>
                    <a href="iniciar.php">Iniciar Sesion</a>
                    <a href="acercade.php">Acerca de</a>
                    <a href="https://www.facebook.com/Where-is-the-bus-151641511912643/v">Contacto</a>
                </nav>
            </div>
        </header>
        
        <main>
                     <br>
                     <br>
                     <br>
                     <br>
                     <br>
                     <br>
            <section id="bienvenidos">
                   <h2>Bienvenidos a Nuestra Pagina Oficial</h2>
            </section>
            
            <section id="blog">
                     <h3>Lo nuevo de nuestro blog</h3>
                 <div class="contenedor">
                     <article>
                           <img src="img/imagen1.jpg">
                           <h4>Turismo</h4>
                     </article>
                     <article>
                           <img src="img/imagen2.jpg">
                           <h4>Centrales</h4>
                     </article>
                     <article>
                           <img src="img/imagen3.jpg">
                           <h4>Autobuses</h4>
                     </article>
                </div>
            </section>
            
        </main>
        
        <footer>
           <div class="contenedor">
                <p class="copy">Where is the Bus? &copy; 2016</p> 
                <div class="sociales">
                   <a class="icon-facebook-official" href="https://www.facebook.com/Where-is-the-bus-151641511912643/v"></a>
               </div>
           </div>
        </footer>
    </body>
</html>
