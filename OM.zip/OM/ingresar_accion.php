
<?php

include("conexion.php");
$sql = "SELECT usuarios.dependencia, usuarios.usuario, usuarios.password, FROM usuarios, reportes WHERE usuario = "$usuario";
  $sqlResultado = mysql_query($sql);
  $row = mysql_fetch_array($sqlResultado);
  $contrasena = $row["contrasena"];
  $idcliente = $row["idcliente"];				
				
   if ($contrasena == md5($txtcontrasena))
   {				   
     //establecermos las variables de sesión
     $_SESSION["nombre_usuario"] = $row["usuario"];
	  $_SESSION["nombre_cliente"] = $row["cliente"];
       
       

    $usuario=$_POST['nom'];
   $clave=$_POST['pass'];


   if(($usuario=="jmas")&&($clave="pass")){
       header('Location: jmas.php');
   }

   else if(($usuario=="cfe")&&($clave="pass")){
      header('Location: cfe.php');
   }

   else if(($usuario=="master")&&($clave="pass")){
      header('Location: master.php');
   }
   
   else if(($usuario=="obraspublicas")&&($clave="pass")){
      header('Location: obraspublicas.php');
   }
   
   else if(($usuario=="serviciospublicos")&&($clave="pass")){
      header('Location: serviciospublicos.php');
   }

else{
    echo('error');
}
?>