<?php
define('DB','db625060452'); 
define('HOST','db625060452.db.1and1.com');
 define('USER','dbo625060452');
 define('PASS','ProyectoUTP2017');
 
 
 $con = mysqli_connect(HOST,USER,PASS,DB) or die('No Se Puede Conectar');
        mysqli_set_charset($con,"utf8");


?>
