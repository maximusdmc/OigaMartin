<?php
$sesion_usuarios="blabla";
session_name($sesion_usuarios); 
session_start();  
?>
<html lang="es">
    <head>
        <title>Oiga Martín!</title>
        <meta charset="UTF-8"> 
        <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1, maximum-scale=1,  minimum-scale=1">
        <link rel="stylesheet" type="text/css" href="css/fontello.css">
        <link rel="stylesheet" type="text/css" HREF="css/estilos.css">
        <link rel="stylesheet" type="text/css" href="css/responder.css">
        <link rel="icon" href="img/ico.ico" type="image/x-icon" />
        <style>
            #map {
                height: 50%;
                width: 100%;
            }
        </style>
    </head>   
    <body>
        <header>
            <div class="contenedor">
                <h1 class="icon-bullhorn">Bienvenido</h1>
                <input type="checkbox" id="menu-bar">
                <label class="icon-menu" for="menu-bar"></label>
                <nav class="menu">
                    <a href="cerrar_accion.php">Cerrar Sesion</a>
                   
                    <a href="https://www.facebook.com/Oiga-Mart%C3%ADn-151641511912643/">Contacto</a>
                </nav>
            </div>
        </header>
        <main>
            <h2 align="center">Listado de quejas</h2> 
            <div>
                <form method="post" action="responder_queja.php">
                    <?php
                      $id=$_REQUEST['id'];    
                      include("conexion.php");
                      $query="SELECT * FROM reportes WHERE id='$id'";
                      $resultado=$conexion->query($query);
                      $row=$resultado->fetch_assoc();
                    ?>
                    <h2>Responder queja</h2>
                    <center> 
                          <img src="<?php echo $row['url_foto']; ?>" width="50%" height="50%" >
                    </center>
                    <br>
                    <center>
                        <div id="map"></div>
                        <script>
                            function initMap() {
                                var uluru = {lat: -25.363, lng: 131.044};
                                var map = new google.maps.Map(document.getElementById('map'), {
                                    zoom: 15,
                                    center: {lat: <?php echo $row['latitud'] ?>, lng: <?php echo $row['longitud'] ?>}
                                });
                                var marker = new google.maps.Marker({
                                    position: {lat: <?php echo $row['latitud'] ?>, lng: <?php echo $row['longitud'] ?>},
                                    map: map
                                });
                            }
                        </script>
                        <script async defer src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDra3qt3a1JBNpU7cncWV3RdcntNAVRWC4&callback=initMap">
                        </script>
                    </center> 
                    <br>
                    <center>
                        <h5>No. Queja</h5>
                        <input type="text" name="id" placeholder="Nombre" value="<?php echo $row['id'] ?>"required>
                        <h5>Nombre</h5>
                        <input type="text" name="nombre" placeholder="Nombre" value="<?php echo $row['nombre'] ?>"required>
                        <h5>Apellidos</h5>
                        <input type="text" name="apellidos" placeholder="Nombre" value="<?php echo $row['apellidos'] ?>"required>
                        <h5>Telefono</h5>
                        <input type="text" name="telefono" placeholder="Telefono" value="<?php echo $row['telefono'] ?>"required>
                        <h5>Correo</h5>
                        <input type="text" name="correo" placeholder="Correo" value="<?php echo $row['correo'] ?>"required>
                        <h5>Latitud</h5>
                        <input type="text" name="latitud" placeholder="Nombre" value="<?php echo $row['latitud'] ?>"required>
                        <h5>Longitud</h5>
                        <input type="text" name="longitud" placeholder="Nombre" value="<?php echo $row['longitud'] ?>"required>
                        <h5>Revisado</h5>
                        <input type="text" name="sulucionado" placeholder="Nombre" value="<?php echo $row['solucionado'] ?>"required>
                        <h5>Fecha</h5>
                        <input type="text" name="fecha" placeholder="Nombre" value="<?php echo $row['fecha'] ?>"required>
                        <h5>Mensaje de Respuesta</h5>
                        <textarea name="mensaje" placeholder="Escriba la respuesta a la queja, se enviara un correo de notificacion" required></textarea>
                        <input type="submit" value="Enviar Correo" id="boton">
                    </center>
                </form> 
            </div>
        </main>
        <footer>
            <div class="contenedor">
                <p class="copy">Oiga Martín! &copy; 2017</p> 
                <div class="sociales">
                   <a class="icon-facebook-official" href="https://www.facebook.com/Oiga-Mart%C3%ADn-151641511912643/"></a>
               </div>
           </div>
        </footer>
    </body>
</html>
