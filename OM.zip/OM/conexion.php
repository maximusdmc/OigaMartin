<?php

    $host = "db625060452.db.1and1.com";
    $hostuser = "dbo625060452";
    $hostpw = "ProyectoUTP2017";
    $hostdb = "db625060452";

    $conexion = mysqli_connect($host,$hostuser,$hostpw,$hostdb);

    if($conexion)
    {
    	return "CONECTADO";
    }else{
    	return "NO CONECTADO";
    }
?>