<?php     
require_once 'dbDetails.php';
$upload_path = 'uploads/';
$server_ip = gethostbyname(gethostname());
$upload_url = 'http://s625060061.onlinehome.mx/android/'.$upload_path; 
$fecha = date("d/m/Y");
$solucion = "no";

$response = array(); 

if($_SERVER['REQUEST_METHOD']=='POST'){
    
    //checking the required parameters from the request 
    if(isset($_POST['name']) and 
       isset($_POST['nombre']) and 
       isset($_POST['apellidos']) and
       isset($_POST['telefono']) and
       isset($_POST['correo']) and
       isset($_POST['t_reporte']) and
       isset($_POST['reporte']) and
       isset($_POST['lat']) and
       isset($_POST['lng']) and
       isset($_FILES['image']['name'])){
        $con = mysqli_connect(HOST,USER,PASS,DB) or die('Unable to Connect...');

        $name = $_POST['name'];
        $nombre = $_POST['nombre'];
        $apellidos = $_POST['apellidos'];
        $telefono = $_POST['telefono'];
        $correo = $_POST['correo'];
        $t_reporte = $_POST['t_reporte'];
        $reporte = $_POST['reporte'];
        $lat = $_POST['lat'];
        $lng = $_POST['lng'];

        $fileinfo = pathinfo($_FILES['image']['name']);
        $extension = $fileinfo['extension'];
        $file_url = $upload_url . getFileName() . '.' . $extension;
        $file_path = $upload_path . getFileName() . '.'. $extension; 
        
        try{
            move_uploaded_file($_FILES['image']['tmp_name'],$file_path);
            $sql = "INSERT INTO `db625060452`.`reportes` (`id`, `nombre`, `apellidos`, `telefono`, `correo`, `dependencia`, `latitud`, `longitud`, `comentario`, `url_foto`, `name`, `solucionado`, `fecha`) 
            VALUES (NULL,'$nombre','$apellidos','$telefono','$correo','$t_reporte','$lat','$lng','$reporte', '$file_url', '$name', '$solucion', '$fecha')";
            if(mysqli_query($con,$sql)){

                $response['error'] = false; 
                $response['url'] = $file_url; 
                $response['name'] = $name;
            }
        }catch(Exception $e){
            $response['error']=true;
            $response['message']=$e->getMessage();
        }		
        echo json_encode($response);
        mysqli_close($con);
    }else{
        $response['error']=true;
        $response['message']='Please choose a file';
    }
}

function getFileName(){
    $con = mysqli_connect(HOST,USER,PASS,DB) or die('Unable to Connect...');
    $sql = "SELECT max(id) as id FROM reportes";
    $result = mysqli_fetch_array(mysqli_query($con,$sql));

    mysqli_close($con);
    if($result['id']==null)
        return 1; 
    else 
        return ++$result['id']; 
}