<?php
include ("conexion.php");
$id=$_REQUEST['id']; 
mysqli_query($conexion, "DELETE from reportes WHERE id='$id'")  or die ("Error al eliminar los datos");

mysqli_close($conexion);

?>
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <meta http-equiv="Refresh" content="2; url=<?php echo $_SERVER['HTTP_REFERER'];?>"> 
        <title>Oiga Martin!</title>
        <script>alert('Reporte eliminado');</script>
        <script>window.history.back(-1);</script>
    </head>
    <body>
        
    </body>
</html>


